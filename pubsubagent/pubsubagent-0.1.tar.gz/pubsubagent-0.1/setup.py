from setuptools import setup, find_packages


#get environ for agent name/identifier
packages = ['pnnl','pnnl.simulation','pnnl.simulation.pubsubagent','pnnl.simulation.pubsubagent.pubsub']
package = packages[-1]

setup(
    name = 'pubsubagent',
    version = "0.1",
    install_requires = ['volttron'],
    packages = packages,
    entry_points = {
        'setuptools.installation': [
            'eggsecutable = ' + package + '.agent:main',
        ]
    }
)

