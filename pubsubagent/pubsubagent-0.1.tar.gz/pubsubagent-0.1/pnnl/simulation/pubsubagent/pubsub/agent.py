import collections
from datetime import datetime
import logging
from volttron.platform.agent import utils
from volttron.platform.messaging import headers as headers_mod
from volttron.platform.vip.agent import Agent, Core


utils.setup_logging()
log = logging.getLogger(__name__)


class PubSubAgent(Agent):
        
    def __init__(self, config_path, **kwargs):
        super(PubSubAgent, self).__init__(**kwargs)
        self.config = utils.load_config(config_path)
        self.INPUTS = collections.OrderedDict()
        self.OUTPUTS = collections.OrderedDict()
        
    
    @Core.receiver('onsetup')
    def setup(self, sender, **kwargs):
        if 'inputs' in self.config: 
            self.INPUTS = self.config['inputs']
        if 'outputs' in self.config:
            self.OUTPUTS = self.config['outputs']
        if 'properties' in self.config:
            self.__dict__.update(self.config['properties'])


    @Core.receiver('onstart')  
    def start(self, sender, **kwargs):
        self.subscribe()
    
    
    def input(self, *args):
        if len(args) == 0:
            return self.INPUTS
        return self.inOut(self.INPUTS, *args)
 
 
    def output(self, *args):
        if len(args) == 0:
            return self.OUTPUTS
        return self.inOut(self.OUTPUTS, *args) 
 
 
    def inOut(self, dct, *args):
        if len(args) >= 1:
            key = args[0]
            if dct.has_key(key):
                if len(args) >= 2:
                    field = args[1]
                    if len(args) >= 3:
                        dct.get(key)[field] = args[2]
                        return args[2]
                    return dct.get(key).get(field)
                return dct.get(key)
        return None
    
    
    def subscribe(self):
        for key, obj in self.input().iteritems():
            if obj.has_key('topic'):
                callback = self.onMatchTopic
                topic = obj.get('topic')
                keyCaps = 'onMatch'+key[0].upper()+key[1:]
                if obj.has_key('callback'):
                    if (hasattr(self, obj.get('callback')) and 
                            callable(getattr(self, obj.get('callback'), None))):
                        callback = getattr(self, obj.get('callback'))
                elif (hasattr(self, keyCaps) and 
                            callable(getattr(self, keyCaps, None))):
                    callback = getattr(self, keyCaps)
                log.info('subscribed to ' + topic)
                self.vip.pubsub.subscribe(peer='pubsub', prefix=topic, callback=callback)

        
    def publishData(self):
        #Publish messages
        for key in self.output():
            self.publish(key)
                    
                    
    def publish(self, *args):
        #Create timestamp
        headers = {headers_mod.DATE: datetime.utcnow().isoformat(' ') + 'Z'}
        #Publish message
        if len(args) == 1 and type(args[0]) == list: things = args[0]
        else: things = args
        for thing in things:
            if type(thing) == str: obj = self.output(thing)
            else: obj = thing
            if obj.has_key('topic') and obj.has_key('value'):
                topic = obj.get('topic', None)
                value = obj.get('value', None)
                if (topic is not None) and (value is not None):
                    log.info('Sending: ' + topic + ' ' + str(value))
                    self.vip.pubsub.publish('pubsub', topic, headers, [value]).get()
                    #gevent.sleep(0.05)

        
    def onMatchTopic(self, peer, sender, bus, topic, headers, message):
        mssg = message if type(message) == type([]) else [message]
        log.info('Received: ' + topic + ' ' + str(mssg[0]))
        self.updateTopic(peer, sender, bus, topic, headers, mssg)
        
        
    def updateTopic(self, peer, sender, bus, topic, headers, message):
        obj = self.getInputFromTopic(topic)
        if obj is not None:
            obj['value'] = message[0]
            obj['last_update'] = 'something'
            self.onUpdateTopic(peer, sender, bus, topic, headers, message)
            
            
    def onUpdateTopic(self, peer, sender, bus, topic, headers, message):
        self.updateComplete()
        
        
    def updateComplete(self):
        self.onUpdateComplete()
        
        
    def onUpdateComplete(self):
        pass
        
        
    def clearLastUpdate(self):
        for obj in self.input().itervalues():
            if obj.has_key('topic'):
                obj['last_update'] = None
        
        
    def getInputFromTopic(self, topic):
        for obj in self.input().itervalues():
            if (obj.get('topic') == topic):
                    return obj
        return None


class SynchronizingPubSubAgent(PubSubAgent):

    def __init__(self, config_path, **kwargs):
        super(SynchronizingPubSubAgent, self).__init__(config_path, **kwargs)
        
    
    @Core.receiver('onstart')  
    def start(self, sender, **kwargs):
        super(SynchronizingPubSubAgent, self).start(sender, **kwargs)
        self.updateComplete()
        
    
    def updateComplete(self):
        if self.allTopicsUpdated():
            self.clearLastUpdate()
            self.onUpdateComplete()
            
            
    def allTopicsUpdated(self):
        for obj in self.input().itervalues():
            if obj.has_key('topic'):
                if (obj.has_key('blocking') and obj.get('blocking')) or not obj.has_key('blocking'):
                    if obj.has_key('last_update'):
                        if obj.get('last_update') is None:
                            return False
                    else:
                        return False
        return True
        
        
    def onUpdateComplete(self):
        self.publishData()
        
    
class Event(object):
        
    @staticmethod
    def post(function, callback, *args):
        condition = True if len(args) == 0 else args[0]
        setattr(function.__self__, function.__name__, Event.__post(function, callback, condition))
    
    
    @staticmethod      
    def __post(function, callback, condition):
        def __wrapper(*args, **kwargs):
            result = function(*args, **kwargs)
            if type(condition) == bool: istrue = condition
            else: istrue = condition()
            if istrue: callback()
            return result
        __wrapper.__name__ = function.__name__
        __wrapper.__self__ = function.__self__
        return __wrapper
    
    
    @staticmethod
    def pre(function, callback, *args):
        condition = True if len(args) == 0 else args[0]
        setattr(function.__self__, function.__name__, Event.__pre(function, callback, condition))
    
    
    @staticmethod      
    def __pre(function, callback, condition):
        def __wrapper(*args, **kwargs):
            if type(condition) == bool: istrue = condition
            else: istrue = condition()
            if istrue: callback()
            result = function(*args, **kwargs)
            return result
        __wrapper.__name__ = function.__name__
        __wrapper.__self__ = function.__self__
        return __wrapper
